package uk.ac.ed.inf.powergrab;

public enum Direction {
	E, ENE, NE, NNE,
	N, NNW, NW, WNW, 
	W, WSW, SW, SSW,
	S, SSE, SE, ESE
}
